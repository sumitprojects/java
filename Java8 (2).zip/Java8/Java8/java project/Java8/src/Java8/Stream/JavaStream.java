package Java8.Stream;

import java.util.*;
import java.util.stream.*;

public class JavaStream {
    public void JavaStreamRun() {
        List<Product> productsList = new ArrayList<>();
        //Adding Products
        productsList.add(new Product(1, "HP Laptop", 25000f));
        productsList.add(new Product(2, "Dell Laptop", 30000f));
        productsList.add(new Product(3, "Lenevo Laptop", 28000f));
        productsList.add(new Product(4, "Sony Laptop", 28000f));
        productsList.add(new Product(5, "Apple Laptop", 90000f));

        //Stream is also used with the Database classes and queries

        /*
        * Java 8 Stream class implementation by using filter method
        * */
        Stream<Product> productPriceList = productsList.stream()
                        .filter(p -> p.price > 25000); // filtering data

        /*
         * Java 8 Stream class implementation by using sum method fot accumulating Total price
         * Method 1
         * */
        Float getTotalPrice1 = productsList.stream()
                .map(p -> p.price)
                .reduce(0.0f, Float::sum)  ; // Sum all Price

        /*
         * Java 8 Stream class implementation by using sum method fot accumulating Total price
         * Method 2
         * */
        Float getTotalPrice2 = productsList.stream()
                .map(p -> p.price)
                .reduce(0.0f, (sum,price)-> sum+price)  ; // Sum all Price by lamda expression


        /*
         * Java 8 Stream class implementation by Using Collectors's method to sum the prices.
         * Method 3
         * */
        double getTotalPrice3 = productsList.stream()
                .collect(Collectors.summingDouble(product->product.price));

        //forEach method is the Java 8 method for iteration any type of collection classes or array
        System.out.println("|---------------|---------------|");
        System.out.println("|Product Name\t|Product Price\t|");
        System.out.println("|---------------|---------------|");
        productPriceList.forEach(product -> System.out.println("|"+product.name + "\t|\t" +product.price+"\t\t|"));
        System.out.println("|---------------|---------------|");
        System.out.println("|TotalPrice -1\t|\t"+getTotalPrice1+"\t|");
        System.out.println("|TotalPrice -2\t|\t"+getTotalPrice2+"\t|");
        System.out.println("|TotalPrice -3\t|\t"+getTotalPrice3+"\t|");
        System.out.println("|---------------|---------------|");
    }
}