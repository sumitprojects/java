package Java8.MethodReferences;
@FunctionalInterface
public interface Talk{
    void say();
}
