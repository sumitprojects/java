package Java8.MethodReferences;

public class NonStaticReference {
    public void saySomething() {
        System.out.println("Hello, this is non-static method.");
    }
}
