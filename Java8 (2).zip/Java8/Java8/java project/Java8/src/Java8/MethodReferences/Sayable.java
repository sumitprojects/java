package Java8.MethodReferences;

//Reference to a non-static method.
@FunctionalInterface
public interface Sayable{
    void say();
}
