package Java8.MethodReferences;

@FunctionalInterface
public interface MethodReferences {
    Message getMessage(String msg);
}
