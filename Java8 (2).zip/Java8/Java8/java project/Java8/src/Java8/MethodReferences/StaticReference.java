package Java8.MethodReferences;

//Reference to a static method.
public class StaticReference {
    public static void saySomething() {
        System.out.println("Hello, this is static method.");
    }
}
