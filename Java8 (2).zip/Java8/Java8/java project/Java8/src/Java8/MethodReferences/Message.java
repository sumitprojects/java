package Java8.MethodReferences;

//Reference to a constructor.
public class Message{
    public Message(String msg){
        System.out.println(msg);
    }
}
