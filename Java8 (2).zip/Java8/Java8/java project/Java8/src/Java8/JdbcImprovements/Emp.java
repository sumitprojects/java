package Java8.JdbcImprovements;

import java.sql.Timestamp;

public class Emp {
    int id;
    String emp_name;
    String emp_desg;
    Timestamp joining;

    public Emp(){

    }

    public Emp(int id, String emp_name, String emp_desg, Timestamp joining) {
        this.id = id;
        this.emp_name = emp_name;
        this.emp_desg = emp_desg;
        this.joining = joining;
    }

    public int getId() {
        return id;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public String getEmp_desg() {
        return emp_desg;
    }

    public Timestamp getJoining() {
        return joining;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public void setEmp_desg(String emp_desg) {
        this.emp_desg = emp_desg;
    }

    public void setJoining(Timestamp joining) {
        this.joining = joining;
    }
}
