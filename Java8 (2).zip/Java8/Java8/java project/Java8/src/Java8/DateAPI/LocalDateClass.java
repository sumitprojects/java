package Java8.DateAPI;

import java.time.LocalDate;
import java.time.Period;

public class LocalDateClass {
    public void DateMethods(){
        LocalDate date = LocalDate.now();
        LocalDate yesterday = date.minusDays(1);
        LocalDate tomorrow = yesterday.plusDays(2);
        LocalDate date2 = LocalDate.of(2016, 9, 23);

        System.out.println("|-------Local Date Method-------|");
        System.out.println("|---------------|---------------|");
        System.out.println("|Today date\t\t|\t"+date+"\t|");
        System.out.println("|-------------------------------|");
        System.out.println("|Yesterday date\t|\t"+yesterday+"\t|");
        System.out.println("|-------------------------------|");
        System.out.println("|Tomorrow date\t|\t"+tomorrow+"\t|");
        System.out.println("|-------------------------------|");
        System.out.println("|Leap:"+date2+"|\t"+date2.isLeapYear()+"\t\t|");
        System.out.println("|---------------|---------------|");
    }
    public void PeriodMethods(){
        LocalDate date = LocalDate.now();
        Period period = Period.of(2018,03,20);
        Period period1 = Period.of(date.getYear(),date.getMonthValue(),date.getDayOfMonth());
        System.out.println("|-------Periods Method----------|");
        System.out.println("|---------------|---------------|");
        System.out.println("|Period 1\t\t|\t"+period+"\t|");
        System.out.println("|Period 2\t\t|\t"+period1+"\t|");
        System.out.println("|Comparision\t|\t"+period.minus(period1)+"\t\t\t|");
        System.out.println("|---------------|---------------|");

    }
}
