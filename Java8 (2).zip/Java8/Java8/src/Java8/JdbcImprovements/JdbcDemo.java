package Java8.JdbcImprovements;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


public class JdbcDemo implements DriverAction {
    Connection con = null;
    Driver driver = null;

    public Connection getConnection() {
        try {
            // Creating driver instance
            Driver driver = new com.mysql.jdbc.Driver();
            // Creating Action Driver
            DriverAction da = new JdbcDemo();
            // Registering driver by passing driver and driverAction
            DriverManager.registerDriver(driver, da);
            // Creating connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee", "root", "mysql");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
    public void getEmps() {
        try {
            con = getConnection();
            Statement stmt = con.createStatement();
            // Executing SQL query
            ResultSet rs = stmt.executeQuery("select * from tbl_emp");
            System.out.println("|\t\t Result set Method \t\t|");
            System.out.println("|\t\t Employee Data \t\t|");
            System.out.println("|-------------------------------------------------------------------------------------|");
            System.out.println("|\tEmployee ID\t|\tEmployee Name\t|\tEmployee Designation\t|\t    Joining Date  |");
            System.out.println("|-------------------------------------------------------------------------------------|");
            while (rs.next()) {
                System.out.println("|\t\t"+rs.getInt(1) + "\t\t|\t\t" + rs.getString(2) + "\t\t|\t\t" + rs.getString(3) + "\t\t\t|" +rs.getString(4)+"|");
            }
            System.out.println("|-------------------------------------------------------------------------------------|");
            // Closing connection
            con.close();
            // Calling deregister method
            deregister();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void deregister() {
        try {
            DriverManager.deregisterDriver(driver);
        } catch (SQLException e) {
            System.out.println(e);
        }
        System.out.println("Driver Disconnected");
    }

    public List<Emp> getAllRecords(){
        List<Emp> list=new ArrayList<>();

        try{
            con=getConnection();
            PreparedStatement ps=con.prepareStatement("select * from tbl_emp");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Emp u=new Emp();
                u.setId(rs.getInt("emp_id"));
                u.setEmp_name(rs.getString("emp_name"));
                u.setEmp_desg(rs.getString("emp_desg"));
                u.setJoining(rs.getTimestamp("modified_date"));
                list.add(u);
            }
        }catch(Exception e){System.out.println(e);}
        deregister();
        return list;
    }

    public void displayEmpStream(){
        List<Emp> empList = getAllRecords();
        Stream<Emp> empStream = empList.stream().filter(u -> u.emp_desg.equalsIgnoreCase("developer"));
        System.out.println("|\t\t Stream Method \t\t|");
        System.out.println("|\t\t Employee Data \t\t|");
        System.out.println("|-------------------------------------------------------------------------------------|");
        System.out.println("|\tEmployee ID\t|\tEmployee Name\t|\tEmployee Designation\t|\t    Joining Date  |");
        System.out.println("|-------------------------------------------------------------------------------------|");
        empStream.forEach(emp -> System.out.println("|\t\t"+emp.id + "\t\t|\t\t" + emp.emp_name + "\t\t|\t\t" + emp.emp_desg + "\t\t\t|" +emp.joining+"|"));
        System.out.println("|-------------------------------------------------------------------------------------|");
    }
}
