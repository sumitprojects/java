package Java8;

import Java8.DateAPI.LocalDateClass;
import Java8.JdbcImprovements.JdbcDemo;
import Java8.Lambda.Lamda;
import Java8.MethodReferences.*;
import Java8.Stream.JavaStream;

import java.util.Scanner;

public class Java8 {

    /**
     * @param args choice for selecting example of Java 8 features
     */
    public static void main(String[] args) {
        Integer choice = 0;
        System.out.println("Java 8 Features");
//        System.out.println("1.Lambda Example\n2.Method References\n3.Java Date&Time\n4.Java Stream\n5.JDBC Improvement\n6.Exit");
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("1.Lambda Example\n2.Method References\n3.Java Date&Time\n4.Java Stream\n5.JDBC Improvement\n6.Exit");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    LambdaRun();
                    break;
                case 2:
                    MethodReferenceRun();
                    break;
                case 3:
                    LocalDateClass l = new LocalDateClass();
                    l.DateMethods();
                    System.out.println();
                    l.PeriodMethods();
                    break;
                case 4:
                    JavaStream js = new JavaStream();
                    js.JavaStreamRun();
                    break;
                case 5:
                    JdbcDemo jd = new JdbcDemo();
                    jd.getEmps();
                    System.out.println("Jdbc example using stream");
                    jd.displayEmpStream();
                    break;
                case 6:
                    System.out.println("Good Bye");
                    System.exit(0);
                    break;
                default:
                    System.err.println("Invalid Choice");
                    break;
            }
            System.out.flush();
        } while (choice != 6);
    }

    /**
     * Lambda Expression Run Method
     */
    public static void LambdaRun() {
        /*
         *    Lamda expression (argument) -> functionality
         */
        Lamda tester = new Lamda();
        System.out.println("******************************");
        System.out.println("\tLamda Example");
        tester.LmbdaRun();
        System.out.println("******************************");
    }

    /**
     * MethodReference example Run Method
     */
    public static void MethodReferenceRun() {
        /*
         * Reference to a constructor.
         *
         * ClassName::new
         */
        System.out.println("******************************");
        System.out.println("\tJava Method References");
        MethodReferences mr = Message::new;//new Message();
        mr.getMessage("Reference to a constructor");

        /*
         *Reference to a static method.
         *
         * ContainingClass::staticMethodName
         */
        Talk mr2 = StaticReference::saySomething;
        mr2.say();
        /*
         *Reference to a non-static method.
         *
         * containingObject::instanceMethodName
         */
        Sayable mr3 = new NonStaticReference()::saySomething;
        mr3.say();
        System.out.println("******************************");

    }
}
